Tracker:AddItems("items/items.json")

if (string.find(Tracker.ActiveVariantUID, "items_only")) then
    Tracker:AddLayouts("items_only/layouts/tracker.json")
    Tracker:AddLayouts("items_only/layouts/broadcast.json")
end

if (string.find(Tracker.ActiveVariantUID, "weapons")) then
    Tracker:AddLayouts("weapons/layouts/tracker.json")
    Tracker:AddLayouts("weapons/layouts/broadcast.json")
end

if (string.find(Tracker.ActiveVariantUID, "expanded")) then
    Tracker:AddLayouts("expanded/layouts/tracker.json")
    Tracker:AddLayouts("expanded/layouts/broadcast.json")
end