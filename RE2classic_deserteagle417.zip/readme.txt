-Clicking handgun upgrades it to custom handgun.
-Left click on shotgun and magnum gives the gun, right click gives the parts.
 Once clicked with both it becomes the custom version.

=========
Changelog
=========

v1.0.1 - improved disabled images for combined items and added chathud support